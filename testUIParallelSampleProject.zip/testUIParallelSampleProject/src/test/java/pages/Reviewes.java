package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import steps.BaseStep;

public class Reviewes {

    @FindBy(xpath="//*[text()='reviews']")
    WebElement reviews;

    public Reviewes()
    {

        AjaxElementLocatorFactory aj = new AjaxElementLocatorFactory(BaseStep.getDriver(),100);
        PageFactory.initElements(aj,this);
        System.out.println("reached inside homepage");

    }

    public void reviewesMenu()
    {
        System.out.println("carsForSaleLink ");
        System.out.println("carsForSaleLink "+reviews.getText());
        Actions action= new Actions(BaseStep.getDriver());
        action.moveToElement(reviews).perform();

    }
}
