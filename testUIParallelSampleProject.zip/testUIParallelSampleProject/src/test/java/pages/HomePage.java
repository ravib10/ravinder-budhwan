package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import steps.BaseStep;

public class HomePage {

    @FindBy(xpath="//*[text()='buy + sell']")
    WebElement carsForSaleLink;

    @FindBy(how=How.LINK_TEXT,using="Sell My Car")
    public WebElement sellMyCarLink;

    @FindBy(how=How.LINK_TEXT,using="Car Reviews")
    public WebElement carReviewsLink;

    @FindBy(how=How.LINK_TEXT,using="Search Cars")
    public WebElement searchCarsLink;

    @FindBy(how=How.LINK_TEXT,using="Used Cars Search")
    public WebElement usedSearchCarsLink;

    //	CarsGuideHomePageLocators carsGuideHomePageLocators=null;
    public HomePage()
    {

        AjaxElementLocatorFactory aj = new AjaxElementLocatorFactory(BaseStep.getDriver(),100);
        PageFactory.initElements(aj,this);
        System.out.println("reached inside homepage");

    }

    public void moveToCarsForSaleMenu()
    {
        System.out.println("carsForSaleLink ");
        System.out.println("carsForSaleLink "+carsForSaleLink.getText());
        Actions action= new Actions(BaseStep.getDriver());
        //action.moveToElement(carsGuideHomePageLocators.carsForSaleLink).perform();
        action.moveToElement(carsForSaleLink).perform();
//        carsForSaleLink.click();
//        BaseStep.getDriver().findElement(By.xpath("//button[text()='Sell my car']")).click();
    }
}
