package steps;

import Constants.constant;
import io.cucumber.java.After;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.time.Duration;

public class BaseStep {

    private WebDriver driver;
    public static ThreadLocal<WebDriver> dr = new ThreadLocal<WebDriver>();
    public final static int TIMEOUT = 30;
    public final static int PAGE_LOAD_TIMEOUT = 50;
    void openBrowser(String browserType) {
        switch (browserType) {
            case constant.chromeBrowser:
                WebDriverManager.chromedriver().setup();
                driver = new ChromeDriver();
                break;
            case constant.firefoxBrowser:
                WebDriverManager.firefoxdriver().setup();
                driver = new FirefoxDriver();
                break;
            case constant.edgeBrowser:
                WebDriverManager.edgedriver().setup();
                driver = new EdgeDriver();
                break;
        }


        setWebDriver(driver);

        getDriver().manage().window().maximize();
        getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(TIMEOUT));
        getDriver().manage().timeouts().pageLoadTimeout(Duration.ofSeconds(PAGE_LOAD_TIMEOUT));
        String window = getDriver().getWindowHandle();
        System.out.println("Window 1111111->" + window);

    }


    public static WebDriver getDriver() {
        return dr.get();
    }

    public static void setWebDriver(WebDriver driver) {
        dr.set(driver);
    }

    void openUrl(String url){
        getDriver().get(url);
    }


    public static void tearDown() {
        if (getDriver() != null) {
            getDriver().close();
            getDriver().quit();
        }

    }
}
