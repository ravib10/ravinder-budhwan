package steps;

import io.cucumber.java.Before;

public class BeforeActions {
//
	@Before
    public static void setUp() {
		//ExtentCucumberFormatter.initiateExtentCucumberFormatter();

    	System.out.println("Before");
//        BaseStep.setWebDriver("edge");
    }
}
