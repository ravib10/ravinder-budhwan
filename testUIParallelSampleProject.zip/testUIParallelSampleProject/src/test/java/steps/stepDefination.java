package steps;


import io.cucumber.java.AfterStep;
import io.cucumber.java.Scenario;
import io.cucumber.java.After;
import io.cucumber.java.BeforeStep;
import io.cucumber.java.en.*;

import io.cucumber.plugin.event.Step;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import pages.HomePage;
import pages.Reviewes;

public class stepDefination extends BaseStep{
    HomePage home;
    Reviewes reviewes;

//@Before
public void initialise(){
    System.out.println("he he i m in before");
    home= new HomePage();
    reviewes = new Reviewes();
}

    @After
    public static void tearDown(Scenario scenario) {

        WebDriver driver=BaseStep.getDriver();
        System.out.println("555555555555 "+scenario.isFailed());
//        if (scenario.isFailed()) {
            byte[] screenshotBytes = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
            scenario.attach(screenshotBytes, "image/png","snapshotName");


        }


    @Given("I open {string} browser")
    public void iOpenBrowser(String browserType) {
        openBrowser(browserType);
        initialise();
    }

    @And("I am on the Home Page {string} of CarsGuide Website")
    public void iAmOnTheHomePageOfCarsGuideWebsite(String url) {
        openUrl(url);
    }

    @When("I move to Car For Sale Menu")
    public void iMoveToCarForSaleMenu() {

home.moveToCarsForSaleMenu();
    }

    @When("I move to Reviews Menu")
    public void iMoveToReviewsMenu() throws InterruptedException {
    reviewes.reviewesMenu();
    Thread.sleep(1000L);
    }
}
