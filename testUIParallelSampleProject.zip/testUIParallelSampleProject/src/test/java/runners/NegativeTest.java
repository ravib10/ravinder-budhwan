package runners;//package runners;


import com.cucumber.listener.ExtentCucumberFormatter;
import cucumber.api.CucumberOptions;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


@CucumberOptions(
        plugin = {"json:target/negative/cucumber.json", "pretty", "html:target/negative/cucumber.html","com.cucumber.listener.ExtentCucumberFormatter"},
        features = "C:\\Users\\ADMIN\\Downloads\\cucumber-testing-master\\src\\test\\resources\\FeatureFiles",
        glue = "steps",
        tags = {"@Used-Car-Search"}
        )

public class NegativeTest {

}


