package Constants;

public class constant {

    public final static String chromeBrowser="chrome";
    public final static String firefoxBrowser="firefox";

    public final static String edgeBrowser="edge";
}
